package org.kh.controls.run;

import org.kh.controls.condition.A_If;
import org.kh.controls.condition.B_Else;
import org.kh.controls.condition.C_Switch;
import org.kh.controls.loop.A_For;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A_If aif = new A_If();
		// aif.method1();
		// aif.method2();

		B_Else bEl = new B_Else();
		// bEl.method1();
		// bEl.method2();
		// bEl.method3();

		C_Switch cSw = new C_Switch();
		// cSw.method1();
		// cSw.method2();
		// cSw.method3();
		 
		A_For aFor = new A_For();
		// aFor.method1();
		// aFor.method2();
		// aFor.method3();
		// aFor.method4();
		// aFor.method5();
		// aFor.method6();
		// aFor.method7();
		aFor.method8();
		 
	}

}
