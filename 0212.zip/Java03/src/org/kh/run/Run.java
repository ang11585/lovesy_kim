package org.kh.run;

import org.kh.operator.A_InDecrease;
import org.kh.operator.B_LogicalNegation;
import org.kh.operator.C_Arithmetic;
import org.kh.operator.D_Comparison;
import org.kh.operator.E_Logical;
import org.kh.operator.F_Compound;
import org.kh.operator.G_Triple;


public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A_InDecrease aInDe = new A_InDecrease();
		/*aInDe.method1();
		aInDe.method2();
		aInDe.method3();
		aInDe.method4();*/
		System.out.println("=======================");
		
		B_LogicalNegation bLogic = new B_LogicalNegation();
		/*bLogic.method1();
		bLogic.method2();*/
		
		C_Arithmetic cArith = new C_Arithmetic();
		/*cArith.method1();
		*/
		D_Comparison dComp = new D_Comparison();
		/*dComp.method1();*/
		
		E_Logical eLogic = new E_Logical();
		//eLogic.method1();
		//eLogic.method2();
		//eLogic.method3();
		
		F_Compound fComp = new F_Compound();
		//fComp.method1();
		
		G_Triple gTri = new G_Triple();
		//gTri.method1();
		//gTri.method2();
		//gTri.method3();
		gTri.method4();
	}
	
		

}
