package org.kh.calc;

public class TestCalc {
	//������ ����
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	int a = 10;
		int b= 20;
		int c = 30;
		
		a++;
		b=(--a)+b;
		c=(a++)+(--b);
		
		System.out.println("a�� ����: " + a);
		System.out.println("b�� ����: " + b);
		System.out.println("c"
				+ ".�� ����: " + c);
*/
		int a = 5;
		int b = 10;
		
		int c = (++a) + b;

		int d = c / a;

		int e = c % a;

		int f = e++;

		int g = (--b) + (d--);

		int h = 2;

		int i = a++ + b / (--c / f) * (g-- - d) % (++e + h);

		System.out.println("a : " + a);
		System.out.println("b : " + b);
		System.out.println("c : " + c);
		System.out.println("d : " + d);
		System.out.println("e : " + e);
		System.out.println("f : " + f);
		System.out.println("g : " + g);
		System.out.println("h : " + h);
		System.out.println("i : " + i);

		
	}

}
