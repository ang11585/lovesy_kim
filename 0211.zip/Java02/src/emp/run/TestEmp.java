package emp.run;

import emp.model.vo.Employee;

public class TestEmp {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.printEmployee();
	}

}
