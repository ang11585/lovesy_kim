package org.kh.data;

public class DataPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1+1);
		System.out.println(1.1 +1.1);
		System.out.println('1'+'1'); //������ ������ ���� 1�� �ν�
		System.out.println("AA" + "1");
		
		//������ �ڷ��� quiz..
		System.out.println("Hello"+'q');
		System.out.println("Hello" + 3.14);
		System.out.println(10+20+"Hello");
		System.out.println("Hello" + 10);
		System.out.println(10+"Hello");
		System.out.println(10+(20+"Hello"));
		System.out.println(10+"Hello"+20);

		//�ƽ�Ű�ڵ� ����..
		char ch1 = 'a';
		char ch2 = 97;
		char ch3 = '\u0061';

		System.out.println(ch1); //a
		System.out.println(ch2); //a
		System.out.println(ch3); //a

		

		
		


		

	}

}
