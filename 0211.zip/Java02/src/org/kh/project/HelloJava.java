package org.kh.project;

public class HelloJava {

	public static void main(String[] args) {
		//System.out.println("I'm iron man...");
		System.out.println("���� ���̾���̴�...");

		// TODO Auto-generated method stub

	}

}
