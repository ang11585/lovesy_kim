package org.kh.controls.loop;

import java.util.Scanner;

public class B_While {
	public void method1() {
		// 1~5 출력

		int i = 1;
		while (i < 6) {
			System.out.println(i + "번째 반복문 수행");
			i++;
		}
	}

	public void method2() {

		int i = 5;
		while (i >= 1) {
			System.out.println(i + "번째 반복문 수행");
			i--;
		}
	}
	
	public void method3() {
		int i = 1;
		while(i<11) {
			System.out.println(i+"번째 반복문 수행");
			i=i+2;
		}
	}
	
	public void method4() {
		Scanner sc = new Scanner(System.in);

		while(true) {
			System.out.println("1~9사이의 양수를 입력해주세요 : ");
			int num1 = sc.nextInt();

			if (1 <= num1 && num1 < 10) {
				int i = 1;
				System.out.println("======" + num1 + "단 출력 ======");
				while (i < 10) {
					System.out.println(num1 + "*" + i + "=" + num1 * i);
					i++;
				}
			} else {
				System.out.println("1~9사이의 양수만 입력해주세요");
			}
		}
	}
	
	public void method5() {
		int num = 1;
		int sum = 0;
		
		while(num != 0) {
			System.out.println("숫자 입력 : ");
			Scanner sc = new Scanner(System.in);
			num = sc.nextInt();
			sum += num;
			
		}
		System.out.println("합계 : " + sum);
	}
	
	public void method6() {
		int i = 0;
		int sum = 0;

		while (i <= 98) {
			System.out.println(i);
			i += 2;
			sum += i;
		}

	}
	
	public void method7() {
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자를 입력해주세용가리");
		int num = sc.nextInt();
		int i = 0;
		int sum = 0;

		while (num > i) {

			if (i % 2 == 0) {
				sum += i;
			}
			i++;
		}
		System.out.println("합계 : " + sum);
	}
	
	
	public void method8() {
		Scanner sc = new Scanner(System.in);

		int i = 0;
		int count = 0;

		System.out.println("문자열을 입력: ");
		String message = sc.nextLine();
		System.out.println("검색할 문자 입력 : ");
		char search = sc.next().charAt(0);
		if (search >= 'A' && search <= 'Z' || 
					search >= 'a' && search <= 'z') {

			while (i < message.length()) {
				if (message.charAt(i) == search) {
					count++;
				}
				i++;
			}
			System.out.println("'" + search 
					+ "'가 포함된 갯수 : " + count);

		} else {
			System.out.println("영문자 아니야~");
		}
	}
}

