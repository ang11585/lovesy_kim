package org.kh.controls.loop;

import java.util.Random;
import java.util.Scanner;

public class A_For {

	public void method1() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i + 1 + "번째 반복문 수행");
		}
	}

	public void method2() {
		for (int i = 5; i > 0; i--) {
			System.out.println(i + "번째 반복문 수행");
		}
	}

	public void method3() {
		for (int i = 1; i <= 10; i = i + 2) {
			System.out.println("출력값 : " + i);
		}
	}
	
	
	public void method4() {
		Scanner sc = new Scanner(System.in);

		for (;;) {
			System.out.print("1~9사이의 양수를 입력하세요 : ");
			int num = sc.nextInt();

			if (num > 0 && num < 10) {
				System.out.println("======" + num + "단======");
				for (int i = 1; i < 10; i++) {
					System.out.println(num + "*" + i + "=" + num * i);
				}
				System.out.println();

			} else {
				System.out.println("다시 입력하세용가리");
			}
		}
	}
	
	public void method5( ) {
		/*
		 * 두개수 입력
		 * 작은수 부터 큰수까지의 모든 정수합 출력
		 * 
		 */
		
		Scanner sc = new Scanner(System.in);

		System.out.println("첫번째 정수를 입력해 주세요:");
		int num1 = sc.nextInt();

		System.out.println("두번째 정수를 입력해 주세요:");
		int num2 = sc.nextInt();

		int sum = 0;
		int max = 0;
		int min = 0;

		if (num1 > num2) {
			max = num1;
			min = num2;
		} else if (num1 < num2) {
			max = num2;
			min = num1;
		} else
			max = num1;
		min = num2;

		for (int i = min; i <= max; i++) {
			sum += i;
		}
		System.out.printf("%d부터 %d까지 합 :%d ", min, max, sum);

	}
	
	public void method6() {
		/*
		 * 정수 입력. 1부터 입력받은 정수까지 수를 홀 짝 나눠서 
		 * 홀수면 "수" , 짝수면 "박"을 출력하세요. 
		 * 4면 수박수박 5면 수박수박수
		 */

		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요 : ");
		int num = sc.nextInt();

		for (int i = 1; i <= num; i++) {
			if (i % 2 == 0) {
				System.out.print("박");
			} else {
				System.out.print("수");

			}
		}
	}
	
	//중첩 for문
	public void method7() {

		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(i);
			}
			System.out.println();
		}
	}
	
	public void method8() {
		/*
		 * 0시 0분부터 23시 59분까지 출력하기
		 */
		for (int hour = 0; hour < 24; hour++) {
			for (int min = 0; min < 60; min++) {
				System.out.printf("%2d시 %2d분\n" ,hour,min );
				
			}
			System.out.println();
		}
	}
	
	public void method9() {
		/*
		 * 한줄에 *가 5번출력 사용자입력한만큼 행수 출력
		 * 
		 */

		Scanner sc = new Scanner(System.in);
		System.out.println("몇줄을 그릴까염?");
		int row = sc.nextInt();

		for (int i = 1; i <= row; i++) {
			for (int j = 1; j < 6; j++) {
				System.out.print("*");
			}
			System.out.println();

		}
	}
	
	public void method10() {
		
		/*
		 * 별찍기 행,열 입력
		 * 줄수 칸수 일치하는 위치에는 줄번호 정수출력
		 * 
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("몇줄을 그릴까염?");
		int row = sc.nextInt();

		System.out.println("몇칸을 그릴까염?");
		int col = sc.nextInt();

		for (int i = 1; i <= row; i++) {

			for (int j = 1; j <= col; j++) {
				if (i == j) {
					System.out.print(i);
				} else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		sc.close();
	}
	
	public void method11_1() {
		System.out.print("1번별");

		for (int i = 1; i <= 6; i++) {
			for (int j = 1; j < i; j++) {
				System.out.print("*");
			}
			System.out.println();

		}

	}

	public void method11_2() {
		System.out.println("2번별");

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5 - i; j++) {
				System.out.print("*");
			}
			System.out.println("");

		}

	}

	public void method11_3() {
		System.out.println("3번별");

		for (int i = 1; i < 6; i++) {
			for (int j = 0; j < 5 - i; j++) {
				System.out.print(" ");
			}

			for (int j = 0; j < i; j++) {
				System.out.print("*");

			}
			System.out.println();
		}
	}

	public void method11_4() {
		System.out.println("4번별");
		for (int i = 1; i < 6; i++) {
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			for (int k = 0; k < 6 - i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void method12() {
		// 난수 구하기
		Random random = new Random();

		// 0~9 난수
		for (int i = 0; i < 10; i++) {
			System.out.println(random.nextInt(10));
		}
		// 1~10 난수
		for (int i = 0; i < 10; i++) {
			System.out.println(random.nextInt(10) + 1);
		}

		// 20~35 난수
		for (int i = 0; i < 5; i++) {
			System.out.println(random.nextInt(16) + 20);

		}
	}
	
	public void method13() {
		/*
		 * 1~10까지 임의의 난수를 정해 1부터 난수까지의 정수 합계 출력
		 */

		Random random = new Random();
		
		int sum = 0;
		int a = random.nextInt(10) + 1;
		
			
		System.out.println("난수 출력 :" + a);
		for (int i = 1; i <= a; i++) {
			sum += i;
		}
		System.out.println("1부터 " + a + "까지의" + " 합계 " + ":" + sum);
	}
	
	public void method14() {
		Random random = new Random();
		Scanner sc = new Scanner(System.in);
		
		for (;;) {
			int ranNum = random.nextInt(2) + 1;

			System.out.println("=====동전 앞 뒤 맞추기=====");
			System.out.print("숫자를 입력해주세요 (1.앞면 / 2. 뒷면) : ");
			int selectNum = sc.nextInt();

			if (selectNum == ranNum) {
				System.out.println("맞췄습니다^^.");
				System.out.println(" ");

			} else {
				System.out.println("땡! 틀렸습니다.");
				System.out.println(" ");

			}
			System.out.println("----------------->restart");
			System.out.println(" ");
		}
		
	}
}


