package org.kh.controls.run;
import org.kh.controls.loop.A_For;
import org.kh.controls.loop.B_While;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A_For aFor = new A_For();
		// aFor.method1();
		// aFor.method2();
		// aFor.method3();
		// aFor.method4();
		// aFor.method5();
		// aFor.method6();
		// aFor.method7();
		//aFor.method8();
		//aFor.method9();
		//aFor.method10();
		/*aFor.method11_1();
		aFor.method11_2();
		aFor.method11_3();
		aFor.method11_4();*/
		//aFor.method12();
		//aFor.method13();
		//aFor.method14();
		
		B_While bWhile = new B_While();
		//bWhile.method1();
		//bWhile.method2();
		//bWhile.method3();
		//bWhile.method4();
		//bWhile.method5();
		//bWhile.method6();
		//bWhile.method6();
		bWhile.method8();





		 
	}

}
